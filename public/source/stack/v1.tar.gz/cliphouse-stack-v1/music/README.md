# Score

The music is generated in code. `score.json` fixes the tempo (112.5 BPM, 4/4), bars, scenes, cues, the list schedules, and the electro sound design. Only the number of list items changes the music: each item adds its own note on its reveal. Wording never changes it.

- `node music/render.mjs` renders silent video with Remotion, generates `out/score.wav` from your `props.json`, and muxes `out/video.mp4` with AAC 48 kHz stereo audio.
- `node music/render.mjs --wav-only` writes the WAV only.
- `score.wav` is the preset's mix, 48 kHz 16-bit stereo, mastered to about -14 LUFS with a -1 dBTP ceiling.
- The same props always produce the same WAV. Needs Node 22.6 or later and ffmpeg.
