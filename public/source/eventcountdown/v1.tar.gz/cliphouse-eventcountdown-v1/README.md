# Eventcountdown by cliphou.se, template v1

This is a native HyperFrames project with a generated score for the cliphou.se `eventcountdown` template.

```bash
npx --yes hyperframes@0.8.146 check
node music/render.mjs          # video with sound: out/video.mp4
npx --yes hyperframes@0.8.146 preview
```

- Change text, colors, and hidden roles (`hide_<role>`) in `variables.json`.
- Change layout and GSAP motion in `index.html`. Word timing comes from the shared cue plan in `music/`, so picture and sound stay in sync.
- See `music/README.md` for the score. `npx --yes hyperframes@0.8.146 render --variables-file variables.json --strict-variables -o out/video.mp4` renders the silent video only.
- GSAP and fonts are local. The composition uses a paused, seekable timeline and no network assets.

The cliphou.se template is MIT-0. GSAP and fonts keep their own licenses.
