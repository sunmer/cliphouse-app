// Render the video silent, then mux the music: from the track start, cut to 8.667 s, faded in 0.3 s and out 1.2 s.
// Usage: node music/render.mjs [track.m4a]   (needs ffmpeg on PATH)
import {execFileSync} from 'node:child_process';
import fs from 'node:fs';
const seconds = 8.666667;
const track = process.argv[2] ?? 'music/lofi-nightshift.m4a';
const fadeOut = Math.min(1.2, seconds / 3);
fs.mkdirSync('out', {recursive: true});
execFileSync('sh', ['-c', "npx --yes hyperframes@0.8.146 render --variables-file variables.json --strict-variables -o out/silent.mp4"], {stdio: 'inherit'});
execFileSync('ffmpeg', ['-v', 'error', '-y', '-i', 'out/silent.mp4', '-i', track, '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy',
  '-af', `atrim=0:${seconds},afade=t=in:st=0:d=0.3,afade=t=out:st=${seconds - fadeOut}:d=${fadeOut},apad=whole_dur=${seconds}`,
  '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2', '-t', String(seconds), '-movflags', '+faststart', 'out/video.mp4'], {stdio: 'inherit'});
fs.rmSync('out/silent.mp4');
console.log('Wrote out/video.mp4');
