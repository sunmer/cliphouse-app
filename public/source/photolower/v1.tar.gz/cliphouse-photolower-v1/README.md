# Photolower by cliphou.se, template v1

This is a standalone Remotion project for the cliphou.se `photolower` template.

```bash
npm ci
npx remotion render src/index.ts photolower out/video.mp4 --props=props.json
npx remotion studio src/index.ts
```

- Change text and colors, and choose a bundled image by ID, in `props.json`. The schema is in `src/videos/photolower/schema.ts`.
- Change layout, motion, and timing in `src/videos/photolower/`. Scene timing is in `meta.ts`.
- Fonts come from pinned Fontsource packages. Images are bundled in `src/videos/photolower/assets/`; `records.json` lists each image's prompt, model, size, and hash. The template uses no network assets and no unseeded randomness.
- The same template version, dependency versions, and props render the same video.

The template is MIT-0: copy, modify, sell, and share it without attribution. Remotion has separate license terms: https://remotion.dev/license
