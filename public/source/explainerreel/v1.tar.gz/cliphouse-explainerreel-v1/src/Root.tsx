import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Explainerreel} from './videos/explainerreel/Explainerreel';
import {explainerreelMeta as meta} from './videos/explainerreel/meta';
import {explainerreelSchema as schema} from './videos/explainerreel/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="explainerreel" component={Explainerreel} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
