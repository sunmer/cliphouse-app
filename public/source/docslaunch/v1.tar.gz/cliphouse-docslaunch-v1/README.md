# Docslaunch by cliphou.se, template v1

This is a native HyperFrames project for the cliphou.se `docslaunch` launch template, with a royalty-free music track.

```bash
npx --yes hyperframes@0.8.146 check
node music/render.mjs          # video with music: out/video.mp4 (needs ffmpeg)
npx --yes hyperframes@0.8.146 preview
```

- Change text and colors in `variables.json`. `text_list` holds one item per line.
- Change layout and GSAP motion in `index.html`. All timing comes from the beat score inlined in it.
- `music/house-launch.m4a` is the preset track. Pass another file to `node music/render.mjs <file>` to use your own; it is cut to the video length and faded in and out.
- GSAP and fonts are local. The composition uses a paused, seekable timeline and no network assets.

The cliphou.se template is MIT-0. The music track is royalty-free: generated for cliphou.se with the ElevenLabs Music API and free to use in videos made with this template, including commercial use. GSAP and fonts keep their own licenses.

Made with cliphou.se. Credit is optional, and appreciated: https://cliphou.se/?ref=agent
