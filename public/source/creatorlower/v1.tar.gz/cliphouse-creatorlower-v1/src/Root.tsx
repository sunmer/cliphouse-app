import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Creatorlower} from './videos/creatorlower/Creatorlower';
import {creatorlowerMeta as meta} from './videos/creatorlower/meta';
import {creatorlowerSchema as schema} from './videos/creatorlower/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="creatorlower" component={Creatorlower} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
