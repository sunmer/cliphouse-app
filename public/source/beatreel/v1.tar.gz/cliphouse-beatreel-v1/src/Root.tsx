import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Beatreel} from './videos/beatreel/Beatreel';
import {beatreelMeta as meta} from './videos/beatreel/meta';
import {beatreelSchema as schema} from './videos/beatreel/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="beatreel" component={Beatreel} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
