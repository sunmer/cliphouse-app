import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Ytoutrocard} from './videos/ytoutrocard/Ytoutrocard';
import {ytoutrocardMeta as meta} from './videos/ytoutrocard/meta';
import {ytoutrocardSchema as schema} from './videos/ytoutrocard/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="ytoutrocard" component={Ytoutrocard} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
