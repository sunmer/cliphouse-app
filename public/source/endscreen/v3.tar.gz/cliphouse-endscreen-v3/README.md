# Endscreen by cliphou.se, template v3

This is a standalone Remotion project for the cliphou.se `endscreen` template.

```bash
npm ci
npx remotion render src/index.ts endscreen out/video.mp4 --props=props.json
npx remotion studio src/index.ts
```

- Change text and colors in `props.json`. The schema is in `src/videos/endscreen/schema.ts`.
- Change layout, motion, and timing in `src/videos/endscreen/`. Scene timing is in `meta.ts`.
- Fonts come from pinned Fontsource packages. The template uses no network assets and no unseeded randomness.
- The same template version, dependency versions, and props render the same video.

The template is MIT-0: copy, modify, sell, and share it without attribution. Remotion has separate license terms: https://remotion.dev/license
