import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import type {Role} from '../contract';
import {clamp, easeIn, easeInOut, easeOut, fit, wrapFit} from '../shared/motion';
import {DISPLAY, MONO_FONT, loadTemplateFonts} from '../shared/fonts';
import {endscreenMeta} from './meta';
import type {EndscreenProps} from './schema';

loadTemplateFonts();

const {width: W, height: H, durationInFrames: D} = endscreenMeta;
const E = endscreenMeta.scenes[1].from; // end-screen start (105); all handoffs are timed from here
const BEAT = 15;
const M = 120;
const TRACK_X0 = M;
const TRACK_X1 = W - M;
const TRACK_L = TRACK_X1 - TRACK_X0;
const TRACK_H = 6;
const TRACK_Y = H - M - TRACK_H / 2;
const FRAME_Y = 300;
const FRAME_W = 640;
const FRAME_H = 360;
const SLOT_X = [M, M + FRAME_W + 40];
const CX = 1640;
const CY = FRAME_Y + FRAME_H / 2;
const R_RING = 150;
const R_DISK = 147;
const R_ORBIT = 176;
const LABEL_Y = FRAME_Y + FRAME_H + 32;
const BRAND_SIZE_MAX = 64;

const expo = Easing.out(Easing.exp);
const prog = (f: number, a: number, b: number, easing: (t: number) => number = expo) =>
  interpolate(f, [a, b], [0, 1], {...clamp, easing});
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const pad = (n: number) => String(n).padStart(2, '0');

// Beat counter: advances by one on every beat with a fast eased step.
const beatSteps = (frame: number, start: number) => {
  const t = frame - start;
  if (t < 0) return 0;
  const k = Math.floor(t / BEAT);
  return k + interpolate(t - k * BEAT, [0, 9], [0, 1], {...clamp, easing: easeOut});
};

// The full progress bar splits into three pieces: two frame top edges and the ring's tangent.
const SEGS = [
  {from: [TRACK_X0, 780], to: [SLOT_X[0], SLOT_X[0] + FRAME_W], y: FRAME_Y},
  {from: [780, 1460], to: [SLOT_X[1], SLOT_X[1] + FRAME_W], y: FRAME_Y},
  {from: [1460, TRACK_X1], to: [CX - R_RING, CX + R_RING], y: CY - R_RING - TRACK_H / 2},
] as const;

const Words: React.FC<{
  text: string;
  role: Role;
  frame: number;
  start: number;
  stagger: number;
  dur?: number;
  exit?: number;
  exitStagger?: number;
  justify?: React.CSSProperties['justifyContent'];
  style?: React.CSSProperties;
}> = ({text, role, frame, start, stagger, dur = 14, exit, exitStagger = 2, justify = 'flex-start', style}) => {
  const words = text.trim().split(/\s+/);
  return (
    <span data-text-role={role} style={{display: 'flex', flexWrap: 'wrap', justifyContent: justify, columnGap: '0.26em', ...style}}>
      {words.map((w, i) => {
        const t = prog(frame, start + i * stagger, start + i * stagger + dur);
        const o = exit === undefined ? 0 : prog(frame, exit + i * exitStagger, exit + i * exitStagger + 12, easeIn);
        return (
          <span key={i} style={{display: 'inline-block', overflow: 'hidden', paddingBottom: '0.14em', marginBottom: '-0.14em'}}>
            <span style={{display: 'inline-block', transform: `translateY(${(1 - t) * 115 - o * 115}%)`}}>{w}</span>
          </span>
        );
      })}
    </span>
  );
};

const PlayGlyph: React.FC<{color: string}> = ({color}) => (
  <svg width={72} height={72} viewBox="0 0 64 64">
    <path d="M22 14 L52 32 L22 50 Z" fill={color} />
  </svg>
);

export const Endscreen: React.FC<EndscreenProps> = ({texts, theme}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fg = theme.foreground;

  // Scene 1: the progress bar fills in six eased steps, one per beat.
  let fill = 0;
  for (let i = 0; i < 6; i++) fill += prog(frame, i * BEAT, i * BEAT + 12) / 6;

  // Countdown: wipes in toward the playhead, then drains back to the frame-0 state.
  const cdIn = prog(frame, E + 45, E + 60);
  const drain = interpolate(frame, [E + 60, D - 1], [1, 0], clamp);
  const dotX = frame < E ? TRACK_X0 + fill * TRACK_L : TRACK_X0 + drain * TRACK_L;
  const dotPop = interpolate(frame, [87, 91, 104], [1, 1.6, 1], {...clamp, easing: easeOut});

  // Handoff: split, rise, fold. Every placeholder is still by frame E+43 = 148.
  const split = prog(frame, E, E + 13, easeInOut);
  const rise = prog(frame, E + 13, E + 27);
  const shrink = prog(frame, E + 25, E + 37, easeInOut);
  const unroll = prog(frame, E + 25, E + 41);
  const draw = prog(frame, E + 25, E + 43, easeOut);
  const disk = prog(frame, E + 31, E + 43);
  const orbitGrow = prog(frame, E + 45, E + 57);
  const orbitAngle = -110 + 45 * beatSteps(frame, E + 45);
  const pillIn = prog(frame, E + 75, E + 86);

  // Strongest moment, last third.
  const flood = prog(frame, E + 315, E + 325);
  const pillFill = prog(frame, E + 330, E + 341);
  const plus = spring({frame: frame - (E + 345), fps, config: {damping: 30, stiffness: 180}});

  const hs = wrapFit(texts.headline, 168, W - 2 * M, 2, 0.62, 60);
  const ss = fit(texts.subhead, 52, W - 2 * M, 0.56);
  const bs = fit(texts.brand, BRAND_SIZE_MAX, 1100, 0.72);
  const cs = wrapFit(texts.cta, 44, 268, 2, 0.62, 22);
  const hWords = texts.headline.trim().split(/\s+/).length;
  const sWords = texts.subhead.trim().split(/\s+/).length;
  const brandChars = [...texts.brand];
  const brandStagger = Math.min(1.5, 18 / Math.max(1, brandChars.length));

  const rem = D - frame;
  const timecode = `00:${pad(Math.floor(rem / fps))}:${pad(rem % fps)}`;
  const C = 2 * Math.PI * R_ORBIT;

  const strip = (offset: number) => {
    const c = (beatSteps(frame, E + 45) + offset) % 16;
    return {s0: Math.min(1, Math.max(0, (c - 8) / 8)), s1: Math.min(1, Math.max(0, c / 8))};
  };

  return (
    <AbsoluteFill style={{width: W, height: H, overflow: 'hidden', background: theme.background, fontFamily: DISPLAY}}>
      {/* Top row: timecode chrome shares the brand row */}
      <div
        style={{
          position: 'absolute',
          right: M,
          top: M,
          height: BRAND_SIZE_MAX,
          display: 'flex',
          alignItems: 'center',
          fontFamily: MONO_FONT,
          fontSize: 28,
          fontWeight: 500,
          letterSpacing: '0.04em',
          fontVariantNumeric: 'tabular-nums',
          color: `${fg}99`,
        }}
      >
        {timecode}
      </div>

      {/* Scene 1 copy */}
      {frame < E + 15 && (
        <div style={{position: 'absolute', left: M, top: FRAME_Y - 10, width: W - 2 * M, display: 'flex', flexDirection: 'column'}}>
          <Words
            text={texts.headline}
            role="headline"
            frame={frame}
            start={6}
            stagger={Math.min(6, 24 / hWords)}
            dur={16}
            exit={90}
            style={{fontSize: hs, fontWeight: 900, lineHeight: 1, letterSpacing: '-0.02em', color: fg}}
          />
          <div style={{marginTop: 44}}>
            <Words
              text={texts.subhead}
              role="subhead"
              frame={frame}
              start={30}
              stagger={Math.min(3, 16 / sWords)}
              exit={93}
              exitStagger={Math.min(1.5, 6 / sWords)}
              style={{fontSize: ss, fontWeight: 500, lineHeight: 1.15, color: `${fg}c4`}}
            />
          </div>
        </div>
      )}

      {/* Placeholder frames, unrolled from their red top edges */}
      {SLOT_X.map((x, i) => {
        const {s0, s1} = strip(i * 5);
        return unroll > 0 ? (
          <div key={i} style={{position: 'absolute', left: x, top: FRAME_Y, width: FRAME_W, height: FRAME_H * unroll, overflow: 'hidden', background: theme.surface}}>
            <div style={{position: 'absolute', left: FRAME_W / 2 - 36, top: FRAME_H / 2 - 36}}>
              <PlayGlyph color={`${fg}38`} />
            </div>
            <div style={{position: 'absolute', left: 32, right: 32, top: FRAME_H - 36, height: 4, background: `${fg}26`}}>
              <div style={{position: 'absolute', top: 0, bottom: 0, left: `${s0 * 100}%`, width: `${(s1 - s0) * 100}%`, background: theme.accent2}} />
            </div>
          </div>
        ) : null;
      })}

      {/* Subscribe ring, orbit, flood, plus */}
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        {disk > 0.001 && <circle cx={CX} cy={CY} r={R_DISK * disk} fill={theme.surface} />}
        {flood > 0 && <circle cx={CX} cy={CY} r={R_DISK * flood} fill={theme.accent} />}
        {draw > 0 &&
          [0, 1].map((sweep) => (
            <path
              key={sweep}
              d={`M ${CX} ${CY - R_RING} A ${R_RING} ${R_RING} 0 0 ${sweep} ${CX} ${CY + R_RING}`}
              fill="none"
              stroke={theme.accent}
              strokeWidth={TRACK_H}
              pathLength={1}
              strokeDasharray="1 1"
              strokeDashoffset={1 - draw}
            />
          ))}
        {orbitGrow > 0 && (
          <circle
            cx={CX}
            cy={CY}
            r={R_ORBIT}
            fill="none"
            stroke={theme.accent2}
            strokeWidth={5}
            strokeDasharray={`${C * (44 / 360) * orbitGrow} ${C}`}
            transform={`rotate(${orbitAngle} ${CX} ${CY})`}
          />
        )}
        {plus > 0.001 && (
          <g transform={`translate(${CX} ${CY}) scale(${plus})`}>
            <rect x={-48} y={-9} width={96} height={18} fill={fg} />
            <rect x={-9} y={-48} width={18} height={96} fill={fg} />
          </g>
        )}
      </svg>

      {/* Track, fills, playhead */}
      <div style={{position: 'absolute', left: TRACK_X0, top: TRACK_Y, width: TRACK_L, height: TRACK_H, background: `${fg}2e`}} />
      {frame >= E + 45 && (
        <div style={{position: 'absolute', left: TRACK_X0, top: TRACK_Y, width: TRACK_L * Math.min(cdIn, drain), height: TRACK_H, background: theme.accent2}} />
      )}
      {frame < E && <div style={{position: 'absolute', left: TRACK_X0, top: TRACK_Y, width: TRACK_L * fill, height: TRACK_H, background: theme.accent}} />}
      {frame >= E &&
        SEGS.map((s, i) => {
          let a = lerp(s.from[0], s.to[0], split);
          let b = lerp(s.from[1], s.to[1], split);
          if (i === 2) {
            a = lerp(a, CX, shrink);
            b = lerp(b, CX, shrink);
          }
          if (b - a < 0.5) return null;
          return <div key={i} style={{position: 'absolute', left: a, top: lerp(TRACK_Y, s.y, rise), width: b - a, height: TRACK_H, background: theme.accent}} />;
        })}
      <div
        style={{
          position: 'absolute',
          left: dotX - 11,
          top: TRACK_Y + TRACK_H / 2 - 11,
          width: 22,
          height: 22,
          borderRadius: '50%',
          background: fg,
          transform: `scale(${dotPop})`,
        }}
      />

      {/* Labels under the frames */}
      {(['point1', 'point2'] as const).map((role, i) => {
        const start = E + 45 + i * BEAT;
        const idx = prog(frame, start, start + 12);
        return (
          <div key={role} style={{position: 'absolute', left: SLOT_X[i], top: LABEL_Y, width: FRAME_W, display: 'flex', alignItems: 'baseline', gap: 22}}>
            <span style={{display: 'inline-block', overflow: 'hidden', fontFamily: MONO_FONT, fontSize: 26, fontWeight: 600, color: theme.accent2}}>
              <span style={{display: 'inline-block', transform: `translateY(${(1 - idx) * 115}%)`}}>{pad(i + 1)}</span>
            </span>
            <Words
              text={texts[role]}
              role={role}
              frame={frame}
              start={start + 2}
              stagger={3}
              style={{fontSize: fit(texts[role], 44, 540, 0.62), fontWeight: 800, lineHeight: 1.05, color: fg, whiteSpace: 'nowrap'}}
            />
          </div>
        );
      })}

      {/* Call to action pill, centered under the ring */}
      <div style={{position: 'absolute', left: CX - 160, top: LABEL_Y - 10, width: 320, display: 'flex', justifyContent: 'center'}}>
        <div style={{position: 'relative', padding: '16px 26px', background: theme.surface, clipPath: `inset(0 ${(1 - pillIn) * 100}% 0 0)`}}>
          <div style={{position: 'absolute', inset: 0, background: theme.accent, clipPath: `inset(0 ${(1 - pillFill) * 100}% 0 0)`}} />
          <div style={{position: 'relative', maxWidth: 268}}>
            <Words
              text={texts.cta}
              role="cta"
              frame={frame}
              start={E + 78}
              stagger={3}
              justify="center"
              style={{fontSize: cs, fontWeight: 800, lineHeight: 1.1, color: fg, textAlign: 'center'}}
            />
          </div>
        </div>
      </div>

      {/* Brand */}
      <div style={{position: 'absolute', left: M, top: M, height: BRAND_SIZE_MAX, display: 'flex', alignItems: 'center'}}>
        <div style={{overflow: 'hidden', paddingBottom: '0.12em', marginBottom: '-0.12em'}}>
          <span data-text-role="brand" style={{display: 'flex', whiteSpace: 'pre', fontSize: bs, fontWeight: 900, lineHeight: 1, letterSpacing: '-0.01em', color: fg}}>
            {brandChars.map((ch, i) => {
              const t = prog(frame, E + 90 + i * brandStagger, E + 90 + i * brandStagger + 14);
              return (
                <span key={i} style={{display: 'inline-block', transform: `translateY(${(1 - t) * 120}%)`}}>
                  {ch}
                </span>
              );
            })}
          </span>
        </div>
      </div>
    </AbsoluteFill>
  );
};
