import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Threesteps} from './videos/threesteps/Threesteps';
import {threestepsMeta as meta} from './videos/threesteps/meta';
import {threestepsSchema as schema} from './videos/threesteps/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="threesteps" component={Threesteps} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
