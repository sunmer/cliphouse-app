import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Retroconsole} from './videos/retroconsole/Retroconsole';
import {retroconsoleMeta as meta} from './videos/retroconsole/meta';
import {retroconsoleSchema as schema} from './videos/retroconsole/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="retroconsole" component={Retroconsole} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
