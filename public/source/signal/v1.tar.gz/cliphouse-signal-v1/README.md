# Signal by cliphou.se, template v1

This is a native HyperFrames project for the cliphou.se `signal` template.

```bash
npx --yes hyperframes@0.8.146 check
npx --yes hyperframes@0.8.146 render --variables-file variables.json --strict-variables -o out/video.mp4
npx --yes hyperframes@0.8.146 preview
```

- Change text and colors in `variables.json`.
- Change layout, timing, and GSAP motion in `index.html`.
- GSAP and fonts are local. The composition uses a paused, seekable timeline and no network assets.

The cliphou.se template is MIT-0. GSAP and fonts keep their own licenses.
