import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Flashdrop} from './videos/flashdrop/Flashdrop';
import {flashdropMeta as meta} from './videos/flashdrop/meta';
import {flashdropSchema as schema} from './videos/flashdrop/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="flashdrop" component={Flashdrop} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
