import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Productpulse} from './videos/productpulse/Productpulse';
import {productpulseMeta as meta} from './videos/productpulse/meta';
import {productpulseSchema as schema} from './videos/productpulse/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="productpulse" component={Productpulse} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
