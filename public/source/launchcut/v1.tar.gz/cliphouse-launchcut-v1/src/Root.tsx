import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Launchcut} from './videos/launchcut/Launchcut';
import {launchcutMeta as meta} from './videos/launchcut/meta';
import {launchcutSchema as schema} from './videos/launchcut/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="launchcut" component={Launchcut} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
